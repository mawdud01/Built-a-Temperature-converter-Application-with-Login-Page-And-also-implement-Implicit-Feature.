package com.example.labone;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText etemp;
    TextView result;
    Button ctof,ftoc,back;
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        MenuInflater inflater =getMenuInflater();
        inflater.inflate(R.menu.example_menu,menu);
        return true;
    }


    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {


            case R.id.item1:

                Intent intent=new Intent(Intent.ACTION_VIEW);
               // intent.setData(Uri.parse("https://www.greenuniversity.com/"));
                startActivity(intent);

                String title = getResources().getString(R.string.share);
                Intent chooser = Intent.createChooser(intent, title);
                startActivity(chooser);




        }
        return super.onOptionsItemSelected(item);
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);




        etemp=findViewById(R.id.etemp);
        result=findViewById(R.id.result);
        ctof=findViewById(R.id.ctof);
        ftoc=findViewById(R.id.ftoc);
        back=findViewById(R.id.back);



        ctof.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(etemp.getText().toString().isEmpty())
                {
                    Toast.makeText(MainActivity.this, "Please Insert any nummber in Above", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    double temp = Double.parseDouble(etemp.getText().toString());
                    double result1 =(temp * 1.8) +32;
                    result.setText(String.valueOf(result1));
                }


            }
        });

        ftoc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(etemp.getText().toString().isEmpty())
                {
                    Toast.makeText(MainActivity.this, "Please Insert any nummber in Above", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    double temp = Double.parseDouble(etemp.getText().toString());
                    double result1 =(temp -32) * .555;
                    result.setText(String.valueOf(result1));
                }
            }
        });


        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(MainActivity.this,Login.class);
                startActivity(intent);
            }
        });


    }









}